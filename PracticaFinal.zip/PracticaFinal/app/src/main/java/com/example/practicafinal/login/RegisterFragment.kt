package com.example.practicafinal.login

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.practicafinal.R
import com.example.practicafinal.data.Aplicacion
import com.example.practicafinal.entity.UserEntity

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RegisterFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_register, container, false)

        val editTextName = view.findViewById<EditText>(R.id.etName)
        val editTextAge = view.findViewById<EditText>(R.id.etAge)
        val editTextEmail = view.findViewById<EditText>(R.id.etEmail)
        val editTextPassword = view.findViewById<EditText>(R.id.etPassword)
        val buttonRegister = view.findViewById<Button>(R.id.btnRegister)

        buttonRegister.setOnClickListener {
            val name = editTextName.text.toString()
            val age = editTextAge.text.toString()
            val email = editTextEmail.text.toString()
            val password = editTextPassword.text.toString()

            if (name.isNotEmpty() && age.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty()) {

                lifecycleScope.launch(Dispatchers.IO) {
                    val existingUser = Aplicacion.bd.userDao().obtenerEmail(email)

                    if (existingUser) {
                        launch(Dispatchers.Main) {
                            Toast.makeText(activity, "Ya existe un usuario con ese correo", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        val newUser = UserEntity(nombre = name, contrasena = password, edad = age, email = email)

                        Aplicacion.bd.userDao().agregarUsuario(newUser)

                        launch(Dispatchers.Main) {
                            Toast.makeText(activity, "Usuario registrado correctamente", Toast.LENGTH_SHORT).show()
                            parentFragmentManager.beginTransaction()
                                .replace(R.id.fragment_container, LoginFragment())
                                .commit()
                        }
                    }
                }
            } else {
                Toast.makeText(activity, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show()
            }
        }

        return view
    }
}
