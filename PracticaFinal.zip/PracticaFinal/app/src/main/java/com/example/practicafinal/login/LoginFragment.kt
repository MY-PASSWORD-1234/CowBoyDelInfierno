package com.example.practicafinal.login
import android.content.Context
import android.media.MediaPlayer
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.practicafinal.CarFragment
import com.example.practicafinal.R
import com.example.practicafinal.data.Aplicacion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class LoginFragment : Fragment(R.layout.fragment_login) {

    private lateinit var edtEmail: EditText
    private lateinit var edtPassword: EditText
    private lateinit var cbRememberMe: CheckBox
    private var mediaPlayer: MediaPlayer? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        edtEmail = view.findViewById(R.id.edtEmail)
        edtPassword = view.findViewById(R.id.edtPassword)
        cbRememberMe = view.findViewById(R.id.cbRememberMe)
        val btnLogin = view.findViewById<Button>(R.id.btnLogin)

        loadSavedUserData()

        btnLogin.setOnClickListener {
            val email = edtEmail.text.toString()
            val password = edtPassword.text.toString()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                lifecycleScope.launch(Dispatchers.IO) {
                    val user = Aplicacion.bd.userDao().obtenerUsuario(email, password)
                    if (user != null) {
                        if (cbRememberMe.isChecked) {
                            saveUserToSharedPreferences(email, password)
                        }

                        launch(Dispatchers.Main) {
                            Toast.makeText(requireContext(), "Login exitoso", Toast.LENGTH_SHORT).show()
                            playLoginSuccessSound()

                            parentFragmentManager.beginTransaction()
                                .replace(R.id.fragment_container, CarFragment())
                                .addToBackStack(null)
                                .commit()
                        }
                    } else {
                        launch(Dispatchers.Main) {
                            Toast.makeText(requireContext(), "Credenciales incorrectas. Verifica tu correo y contraseña.", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            } else {
                Toast.makeText(requireContext(), "Por favor, ingresa todos los campos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveUserToSharedPreferences(email: String, password: String) {
        val sharedPreferences = requireActivity().getSharedPreferences("userPrefs", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("userEmail", email)
        editor.putString("userPassword", password)
        editor.putBoolean("isLoggedIn", true)
        editor.putBoolean("rememberMe", true)
        editor.apply()
    }

    private fun loadSavedUserData() {
        val sharedPreferences = requireActivity().getSharedPreferences("userPrefs", Context.MODE_PRIVATE)
        val isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false)

        if (isLoggedIn) {
            val savedEmail = sharedPreferences.getString("userEmail", "")
            val savedPassword = sharedPreferences.getString("userPassword", "")
            edtEmail.setText(savedEmail)
            edtPassword.setText(savedPassword)
            cbRememberMe.isChecked = true
        }
    }

    private fun playLoginSuccessSound() {
        mediaPlayer = MediaPlayer.create(requireContext(), R.raw.ai_2)
        mediaPlayer?.start()

        mediaPlayer?.setOnCompletionListener {
            it.release()
        }
    }


}
