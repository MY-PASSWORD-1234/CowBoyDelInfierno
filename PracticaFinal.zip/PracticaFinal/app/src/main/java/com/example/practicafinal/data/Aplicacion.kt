package com.example.practicafinal.data

import android.app.Application
import androidx.room.Room
import com.example.practicafinal.data.Aplicacion.Companion.bd
import com.example.practicafinal.entity.Car
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class Aplicacion : Application() {
    companion object {
        lateinit var bd: BD
    }

    override fun onCreate() {
        super.onCreate()


        bd = Room.databaseBuilder(
            applicationContext,
            BD::class.java,
            "BDFinal"
        )
            .fallbackToDestructiveMigration()
            .build()
        añadirCoches()

    }
}
@OptIn(DelicateCoroutinesApi::class)
private fun añadirCoches() {
    GlobalScope.launch(Dispatchers.IO) {
        val cochesObtenidos = bd.carDao().getAllCars()

        if (cochesObtenidos.isEmpty()) {
            listOf(
                Car(
                    id = 0,
                    marca = "Toyota",
                    model = "Corolla",
                    descripcion = "Coche confiable y eficiente.",
                    imageUrl = "https://ejemplo.com/toyota_corolla.jpg",
                    cv = "132",
                    combustible = "Gasolina"
                ),
                Car(
                    id = 0,
                    marca = "Honda",
                    model = "Civic",
                    descripcion = "Deportivo y económico.",
                    imageUrl = "https://ejemplo.com/honda_civic.jpg",
                    cv = "158",
                    combustible = "Gasolina"
                ),
                Car(
                    id = 0,
                    marca = "Ford",
                    model = "Mustang",
                    descripcion = "Alto rendimiento y potencia.",
                    imageUrl = "https://ejemplo.com/ford_mustang.jpg",
                    cv = "450",
                    combustible = "Gasolina"
                ),
                Car(
                    id = 0,
                    marca = "Tesla",
                    model = "Model S",
                    descripcion = "Eléctrico de lujo.",
                    imageUrl = "https://ejemplo.com/tesla_model_s.jpg",
                    cv = "1020",
                    combustible = "Eléctrico"
                ),
                Car(
                    id = 0,
                    marca = "BMW",
                    model = "M3",
                    descripcion = "Deportivo de alto rendimiento.",
                    imageUrl = "https://ejemplo.com/bmw_m3.jpg",
                    cv = "503",
                    combustible = "Gasolina"
                )
            ).forEach { coche ->
                bd.carDao().insertCar(coche)
            }
        }
    }
}
