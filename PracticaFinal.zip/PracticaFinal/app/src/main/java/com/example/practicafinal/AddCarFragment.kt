package com.example.practicafinal

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.practicafinal.entity.Car
import com.example.practicafinal.data.Aplicacion
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AddCarFragment : Fragment(R.layout.fragment_add_car) {

    private lateinit var edtMarca: EditText
    private lateinit var edtModel: EditText
    private lateinit var edtCv: EditText
    private lateinit var edtDescripcion: EditText
    private lateinit var edtImage: EditText
    private lateinit var edtCombustible: EditText
    private lateinit var btnSave: Button

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        edtMarca = view.findViewById(R.id.edtMarca)
        edtModel = view.findViewById(R.id.edtModel)
        edtCv = view.findViewById(R.id.edtCV)
        edtDescripcion = view.findViewById(R.id.edtDescripcion)
        edtImage = view.findViewById(R.id.edtimage)
        edtCombustible = view.findViewById(R.id.edtcombustible)
        btnSave = view.findViewById(R.id.btnCrear)

        btnSave.setOnClickListener {
            val marca = edtMarca.text.toString()
            val model = edtModel.text.toString()
            val cv = edtCv.text.toString().toIntOrNull()
            val combustible = edtCombustible.text.toString()
            val imageUrl = edtImage.text.toString()

            if (marca.isNotEmpty() && model.isNotEmpty() && cv != null && combustible.isNotEmpty() && imageUrl.isNotEmpty()) {
                val newCar = Car(0, marca, model, "", imageUrl, cv.toString(), combustible)


                lifecycleScope.launch(Dispatchers.IO) {
                    try {

                        Aplicacion.bd.carDao().insertCar(newCar)

                        withContext(Dispatchers.Main) {
                            Snackbar.make(view, "Coche añadido con éxito", Snackbar.LENGTH_SHORT).show()
                            requireActivity().onBackPressed()
                        }
                    } catch (e: Exception) {
                        withContext(Dispatchers.Main) {
                            Snackbar.make(view, "Error al añadir el coche", Snackbar.LENGTH_SHORT).show()
                        }
                    }
                }
            } else {
                Snackbar.make(view, "Por favor, completa todos los campos", Snackbar.LENGTH_SHORT).show()
            }
        }
    }
}
