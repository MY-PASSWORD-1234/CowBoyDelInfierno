package com.example.practicafinal.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.practicafinal.entity.UserEntity

@Dao
interface UsuarioDao {
    @Query("SELECT * FROM UsuarioEntity WHERE email = :email AND contrasena = :contrasena")
    suspend fun obtenerUsuario(email: String, contrasena: String): UserEntity?

    @Query("SELECT EXISTS(SELECT email FROM UsuarioEntity WHERE email = :email)")
    suspend fun obtenerEmail(email: String): Boolean

    @Insert
    suspend fun agregarUsuario(usuarioEntity: UserEntity)

    @Update
    suspend fun actualizarUsuario(usuarioEntity: UserEntity)

    @Delete
    suspend fun borrarUsuario(usuarioEntity: UserEntity)
}

