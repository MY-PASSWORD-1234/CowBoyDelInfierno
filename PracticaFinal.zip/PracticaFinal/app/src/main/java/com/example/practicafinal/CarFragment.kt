package com.example.practicafinal

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.practicafinal.data.Aplicacion
import com.example.practicafinal.entity.Car
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CarFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var carAdapter: CarAdapter
    private lateinit var fabAddCar: FloatingActionButton

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_car, container, false)
        recyclerView = view.findViewById(R.id.recyclerViewCars)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        carAdapter = CarAdapter(emptyList())
        recyclerView.adapter = carAdapter

        loadCarsFromDatabase()


        fabAddCar = view.findViewById(R.id.fabAddCar)


        fabAddCar.setOnClickListener {

            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, AddCarFragment())
                .addToBackStack(null)
                .commit()
        }

        return view
    }

    private fun loadCarsFromDatabase() {
        lifecycleScope.launch(Dispatchers.IO) {
            val carList: List<Car> = Aplicacion.bd.carDao().getAllCars()

            withContext(Dispatchers.Main) {
                carAdapter.updateData(carList)
            }
        }
    }
}
