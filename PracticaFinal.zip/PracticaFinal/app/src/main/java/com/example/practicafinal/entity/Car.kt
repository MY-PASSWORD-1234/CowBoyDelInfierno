package com.example.practicafinal.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "car")
data class Car(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val marca: String,
    val model: String,
    val descripcion: String,
    val imageUrl: String,
    val cv: String,
    val combustible: String

)