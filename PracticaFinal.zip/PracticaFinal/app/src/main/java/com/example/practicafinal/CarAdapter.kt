package com.example.practicafinal

import android.view.LayoutInflater

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.practicafinal.databinding.CardCarItemBinding
import com.example.practicafinal.entity.Car

import com.bumptech.glide.Glide


class CarAdapter(private var cars: List<Car>) :
    RecyclerView.Adapter<CarAdapter.CarViewHolder>() {

    class CarViewHolder(val binding: CardCarItemBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CarViewHolder {
        val binding = CardCarItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CarViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CarViewHolder, position: Int) {
        val car = cars[position]

        holder.binding.tvModelo.text = "${car.marca} ${car.model}"
        holder.binding.tvCv.text = "CV: ${car.cv}"
         Glide.with(holder.binding.ivModelo)
             .load(car.imageUrl)
             .into(holder.binding.ivModelo)
    }

    override fun getItemCount(): Int = cars.size

    fun updateData(newCars: List<Car>) {
        cars = newCars
        notifyDataSetChanged()
    }
}
