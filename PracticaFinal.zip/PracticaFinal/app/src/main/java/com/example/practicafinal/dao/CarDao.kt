package com.example.practicafinal.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.practicafinal.entity.Car
@Dao
interface CarDao {
    @Query("SELECT * FROM Car")
    fun getAllCars(): List<Car>

    @Insert
    fun insertCar(car: Car)

    @Insert
    fun insertAll(cars: List<Car>)
    @Update
    fun updateCar(car: Car)

    @Delete
    fun deleteCar(car: Car)
}
