package com.example.practicafinal

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.commit
import com.example.practicafinal.login.LoginFragment
import com.example.practicafinal.login.RegisterFragment

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val fragmentType = intent.getStringExtra("fragment_type")

        if (fragmentType == "login") {
            supportFragmentManager.commit {
                replace(R.id.fragment_container, LoginFragment())
            }
        } else if (fragmentType == "register") {
            supportFragmentManager.commit {
                replace(R.id.fragment_container, RegisterFragment())
            }
        }
    }
}
