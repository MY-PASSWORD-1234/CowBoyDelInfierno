package com.example.practicafinal.entity

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "UsuarioEntity")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) var id: Long = 0L,
    var email: String? = "",
    var nombre: String? = "",
    var contrasena: String? = "",
    var edad: String? = ""
)

