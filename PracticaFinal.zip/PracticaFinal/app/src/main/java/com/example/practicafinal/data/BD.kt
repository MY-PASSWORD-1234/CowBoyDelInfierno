package com.example.practicafinal.data

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.practicafinal.dao.CarDao
import com.example.practicafinal.dao.UsuarioDao
import com.example.practicafinal.entity.Car
import com.example.practicafinal.entity.UserEntity


@Database(entities = [Car::class, UserEntity::class], version = 3)
abstract class BD : RoomDatabase() {
    abstract fun userDao(): UsuarioDao
    abstract fun carDao(): CarDao

}
