package com.example.practicafinal.login

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.practicafinal.MainActivity
import com.example.practicafinal.R

class SplashScreenActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        findViewById<Button>(R.id.btnLogin).setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                putExtra("fragment_type", "login")
            }
            startActivity(intent)
        }

        findViewById<Button>(R.id.btnRegister).setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                putExtra("fragment_type", "register")
            }
            startActivity(intent)
        }
    }
}
